package tools;

public interface ISampler {
    public Color getColor(Vec2 p);
}
