package cgg.a02;


import tools.*;

public class Main {
    
}
