package cgg.a02;

import java.text.Normalizer;
import tools.Vec3;

public record Ray(Vec3 ursprung, Vec3 direction, double tMin, double tMax) {
    
    public Ray {

    }

    public Ray(Vec3 pos, Vec3 dir) {
        this(pos, dir, 0, Double.MAX_VALUE);
    }

    public Vec3 pointAt(double t) {
        return ursprung, tMin, direction;
    }

    public boolean isValid(double t) {

    }




    
}
